package com.constr;

public class Constr {
	Constr(){System.out.println("Default constructor");}

	public static void main(String[] args) {
		
		Constr b =new Constr();  
		}  

	}

